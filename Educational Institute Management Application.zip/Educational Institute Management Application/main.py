from operations.assignment_management import *
from operations.course_management import *
from operations.relations_management import *
from operations.student_management import *
from operations.trainer_management import *

keepRunning = True

while keepRunning:
    command = input('Please give command.\n')

    if command == 'exit':
        keepRunning = False

#START Gets
    elif command == 'get students':
        printAllStudents()
    elif command == 'get trainers':
        printAllTrainers()
    elif command == 'get courses':
        printAllCourses()
    elif command == 'get assignments':
        printAllAssignments()
    elif command == 'get students-courses':
        printAllStudents_Courses()
    elif command == 'get trainers-courses':
        printAllTrainers_Courses()
    elif command == 'get students-assignments':
        printAllStudents_Assignments()
#END

#Start Inserts
    elif command == 'insert student':
        insertNewStudent()
    elif command == 'insert trainer':
        insertNewTrainer()
    elif command == 'insert course':
        insertNewCourse()
    elif command == 'insert assignment':
        insertNewAssignment()
#END


#Start Student_Course relationships
    elif command == 'insert student-course relation':
        insertStudentCourseRelation()
#END

#Start Trainer_Course relationships
    elif command == 'insert trainer-course relation':
        inserttrainerCourseRelation()
#END

#Start Student-Assignment relationships
    elif command == 'insert student-assign relation':
        insertStudentAssignmentRelation()

    elif command == 'get students enrolled in multiple courses':
        studentsMultipleCourses()
#Start
    else:
        print('Unkown command!!')
