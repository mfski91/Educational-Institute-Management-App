from models.collections import Assignments


class Assignment:
    def __init__(self, title, description, subDateTime, oralMark, totalMark):
        self._title = title
        self._description = description
        self._subDateTime = subDateTime
        self._oralMark = oralMark
        self._totalMark = totalMark
        if Assignments.__len__() > 0:
            self._id = Assignments[Assignments.__len__() - 1]._id + 1
        else:
            self._id = 1
        Assignments.append(self)

    @property
    def get_id(self):
        return self._id

    @get_id.setter
    def set_id(self, value):
        self._id = value

    @property
    def get_title(self):
        return self._title

    @get_title.setter
    def set_title(self, value):
        self._title = value

    @property
    def get_description(self):
        return self._description

    @get_description.setter
    def set_description(self, value):
        self._description = value

    @property
    def get_subDateTime(self):
        return self._subDateTime

    @get_subDateTime.setter
    def set_subDateTime(self, value):
        self._subDateTime = value

    @property
    def get_oralMark(self):
        return self._oralMark

    @get_oralMark.setter
    def set_oralMark(self, value):
        self._oralMark = value

    @property
    def get_totalMark(self):
        return self._totalMark

    @get_totalMark.setter
    def set_totalMark(self, value):
        self._totalMark = value

    def __str__(self):
        return f"Id:{self._id},Title: {self._title} Description: {self._description} Submission: {self._subDateTime} Oral Mark: {self._oralMark} Total Mark: {self._totalMark}"


Assignment1 = Assignment('IP1', 'Individual Project 1', '2022-01-17', 20, 100)
Assignment2 = Assignment('IP2', 'Individual Project 2', '2022-01-31', 20, 100)
Assignment3 = Assignment('IP3', 'Individual Project 3', '2022-02-07', 20, 100)
Assignment4 = Assignment('GP1', 'Individual Project 1', '2022-01-31', 20, 100)
Assignment5 = Assignment('GP2', 'Individual Project 1', '2022-02-28', 20, 100)
Assignment6 = Assignment('GP3', 'Individual Project 1', '2022-03-31', 20, 100)
