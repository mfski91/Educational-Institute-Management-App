from models.collections import Courses


class Course:
    def __init__(self, title, stream, type, start_date, end_date):
        self._title = title
        self._stream = stream
        self._type = type
        self._start_date = start_date
        self._end_date = end_date
        if Courses.__len__() > 0:
            self._id = Courses[Courses.__len__() - 1]._id + 1
        else:
            self._id = 1
        Courses.append(self)

    @property
    def get_id(self):
        return self._id

    @get_id.setter
    def set_id(self, value):
        self._id = value

    @property
    def get_title(self):
        return self._title

    @get_title.setter
    def set_title(self, value):
        self._title = value

    @property
    def get_stream(self):
        return self._stream

    @get_stream.setter
    def set_stream(self, value):
        self._stream = value

    @property
    def get_type(self):
        return self._type

    @get_type.setter
    def set_type(self, value):
        self._type = value

    @property
    def get_start_date(self):
        return self._start_date

    @get_start_date.setter
    def set_start_date(self, value):
        self._start_date = value

    @property
    def get_end_date(self):
        return self._end_date

    @get_end_date.setter
    def set_end_date(self, value):
        self._end_date = value

    def __str__(self):
        return f"Id:{self._id},Course Title: {self._title} Stream: {self._stream} Type: {self._type} Start Date: {self._start_date} End Date: {self._end_date}"


Course1 = Course('CB1', 'Python', 'Full-Time', '2022-01-03', '2022-06-30')
Course2 = Course('CB2', 'Java', 'Full-Time', '2022-01-03', '2022-06-30')
Course3 = Course('CB3', 'C', 'Full-Time', '2022-01-03', '2022-06-30')
Course4 = Course('CB4', 'Python', 'Part-Time', '2022-01-03', '2022-03-31')
Course5 = Course('CB5', 'Java', 'Part-Time', '2022-01-03', '2022-03-31')
Course6 = Course('CB6', 'C', 'Part-Time', '2022-01-03', '2022-03-31')
