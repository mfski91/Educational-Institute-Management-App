from models.collections import Students


class Student:
    def __init__(self,firstName,lastName,dateOfBirth,tuitionFees):
        self._firstName=firstName
        self._lastName=lastName
        self._dateOfBirth=dateOfBirth
        self._tuitionFees=tuitionFees
        if Students.__len__() > 0:
            self._id = Students[Students.__len__() - 1]._id + 1
        else:
            self._id = 1
        Students.append(self)
    
    @property    
    def get_id(self):
        return self._id
    @get_id.setter
    def set_id(self,value):
        self._id=value
    
    @property    
    def get_firstName(self):
        return self._firstName
    @get_firstName.setter
    def set_firstName(self,value):
        self._firstName=value
    
    @property
    def get_lastName(self):
        return self._lastName
    @get_lastName.setter
    def set_lastName(self,value):
        self._lastName=value
    
    @property
    def get_dateOfBirth(self):
        return self._dateOfBirth
    @get_dateOfBirth.setter
    def set_dateOfBirth(self,value):
        self._dateOfBirth=value
    
    @property
    def get_tuitionFees(self):
        return self._tuitionFees
    @get_lastName.setter
    def set_tuitionFees(self,tuitionFees):
        self._tuitionFees=tuitionFees

    def __str__(self):
        return f"Id:{self._id},First Name: {self._firstName} Last Name: {self._lastName} Date of Birth: {self._dateOfBirth} Tuition Fees: {self._tuitionFees}"

Student1 = Student('Mark','Turner','1991-09-07','2500')
Student2 = Student('John','Doe','1989-09-07','1500')
Student3 = Student('Mary','Poppins','1982-09-07','2500')
Student4 = Student('Mary','Howard','1995-09-07','2500')
Student5 = Student('William','Turner','1991-09-07','500')
Student6 = Student('Helen','Rhodes','1991-09-07','2500')
Student7 = Student('Anne','Page','1991-09-07','2500')
Student8 = Student('Levi','Ackerman','1991-09-07','2500')
Student9 = Student('Eren','Yaeger','1991-09-07','2500')