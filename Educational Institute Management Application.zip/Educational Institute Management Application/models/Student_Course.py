from models.collections import Students_Courses


class Student_Course:
    def __init__(self, studentID, courseID):
        self._studentID = studentID
        self._courseID = courseID
        if Students_Courses.__len__() > 0:
            self._id = Students_Courses[Students_Courses.__len__() - 1]._id + 1
        else:
            self._id = 1
        Students_Courses.append(self)

    @property
    def get_studentID(self):
        return self._studentID

    @get_studentID.setter
    def set_studentID(self, value):
        self._studentID = value

    @property
    def get_courseID(self):
        return self._courseID

    @get_courseID.setter
    def set_courseID(self, value):
        self._courseID = value

    @property
    def get_id(self):
        return self._id

    @get_id.setter
    def set_id(self, value):
        self._id = value

    def __str__(self):
        return f"ID: {self._id} Course ID: {self._courseID} Student ID: {self._studentID}"
