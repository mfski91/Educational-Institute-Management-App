from models.collections import Students_Courses_Assignments


class Student_Course_Assignment:
    def __init__(self, student_course_ID, assignmentID):
        self._student_course_ID_relation = student_course_ID,
        self._assignmentID = assignmentID
        if Students_Courses_Assignments.__len__() > 0:
            self._id = Students_Courses_Assignments[
                Students_Courses_Assignments.__len__() - 1]._id + 1
        else:
            self._id = 1
        Students_Courses_Assignments.append(self)

    @property
    def get_student_course_ID(self):
        return self._student_course_ID_relation

    @property
    def get_assignmentID(self):
        return self._assignmentID

    @property
    def get_id(self):
        return self._id

    @get_id.setter
    def set_id(self, value):
        self._id = value

    @get_student_course_ID.setter
    def set_student_course_ID(self, value):
        self._student_course_ID_relation = value

    @get_assignmentID.setter
    def set_assignmentID(self, value):
        self._assignmentID = value

    def __str__(self):
        return f'ID: {self._id} student-course ID: {self._student_course_ID_relation} assignment ID:{self._assignmentID}'