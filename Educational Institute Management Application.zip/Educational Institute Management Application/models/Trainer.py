from models.collections import Trainers


class Trainer:
    def __init__(self, firstName, lastName, subject):
        self._firstName = firstName
        self._lastName = lastName
        self._subject = subject
        if Trainers.__len__() > 0:
            self._id = Trainers[Trainers.__len__() - 1]._id + 1
        else:
            self._id = 1
        Trainers.append(self)

    @property
    def get_id(self):
        return self._id

    @get_id.setter
    def set_id(self, value):
        self._id = value

    @property
    def get_firstName(self):
        return self._firstName

    @get_firstName.setter
    def set_firstName(self, value):
        self._firstName = value

    @property
    def get_lastName(self):
        return self._lastName

    @get_lastName.setter
    def set_lastName(self, value):
        self._lastName = value

    @property
    def get_subject(self):
        return self._subject

    @get_subject.setter
    def set_subject(self, value):
        self._subject = value

    def get_id(self):
        return self._id

    def __str__(self):
        return f"ID: {self._id} First Name: {self._firstName} Last Name: {self._lastName} Subject: {self._subject}"


Trainer1 = Trainer('Hanna', 'Black', 'Python')
Trainer2 = Trainer('Susan', 'Hope', 'Java')
Trainer3 = Trainer('Bella', 'Jules', 'C')
