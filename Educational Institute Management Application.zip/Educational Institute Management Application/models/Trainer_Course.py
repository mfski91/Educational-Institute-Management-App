from models.collections import Trainers_Courses


class Trainer_Course:
    def __init__(self, trainerID, courseID):
        self._trainerID = trainerID
        self._courseID = courseID
        if Trainers_Courses.__len__() > 0:
            self._id = Trainers_Courses[Trainers_Courses.__len__() -
                                           1]._id + 1
        else:
            self._id = 1
        Trainers_Courses.append(self)
    
    @property
    def get_trainerID(self):
        return self._trainerID
    @get_trainerID.setter
    def set_trainerID(self, value):
        self._trainerID = value
    
    @property
    def get_courseID(self):
        return self._courseID
    @get_courseID.setter
    def set_courseID(self, value):
        self._courseID = value
    
    @property
    def get_id(self):
        return self._id

    def __str__(self):
        return f"ID: {self._id} Course ID: {self._courseID} Trainer ID: {self._trainerID}"
