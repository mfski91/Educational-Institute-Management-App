
Trainers = []
Students = []
Courses = []
Assignments = []

Students_Courses = []
Trainers_Courses = []
Students_Courses_Assignments = []
Courses_Assignments = []
Students_Multiple_Courses = []