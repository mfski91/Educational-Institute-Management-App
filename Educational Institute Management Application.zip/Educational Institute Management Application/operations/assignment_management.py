from models.Assignment import Assignment
from models.collections import Assignments

from operations.helper import DateInputToDate


def isAssignmentEntryExist(assignmentID):
    isExist = False
    for i in range(0, len(Assignments), 1):
        if Assignments[i].get_id == assignmentID:
            isExist = True
            break
    return isExist


def printAllAssignments():
    print("Current Assignments\n")
    for assignment in Assignments:
        print(assignment.__str__())


def insertNewAssignment():
    insertNewassignment = True

    while insertNewassignment:
        date = DateInputToDate('submission')
        Assignment(str(input("Enter Title: ")),
                   str(input("Enter Description: ")), date,
                   int(input("Enter Oral mark: ")),
                   int(input("Enter Total mark: ")))
        insertNewassignment = input(
            "Add new assignment?\nPress N to stop else hit Enter ") != "N"

    printAllAssignments()

