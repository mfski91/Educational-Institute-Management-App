from models.Course import Course
from models.collections import Courses
from operations.helper import DateInputToDate


def isCourseEntryExist(courseID):
    isExist = False
    for i in range(0, len(Courses), 1):
        if Courses[i].get_id == courseID:
            isExist = True
            break
    return isExist
    

def printAllCourses():
    print("Current courses\n")
    for course in Courses:
        print(course.__str__())


def insertNewCourse():
    insertNewCourse = True

    while insertNewCourse:
        startDate = DateInputToDate('start')
        endDate = DateInputToDate('end')
        Course(str(input("Enter title: ")),
               str(input("Enter stream: ")),
               str(input("Enter type: ")), startDate, endDate)
        insertNewCourse = input(
            "Add new course?\nPress N to stop else hit Enter ") != "N"

    printAllCourses()

