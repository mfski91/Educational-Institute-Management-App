import datetime


def DateInputToDate(dateType=None):
    try:
        dateInput = input(f'Enter {dateType} date in the DD-MM-YYYY format ')
        day, month, year = dateInput.split('-')
        date = datetime.date(int(year), int(month), int(day))
    except Exception as ex:
        print(ex)
        return DateInputToDate(dateType)
    else:
        return date