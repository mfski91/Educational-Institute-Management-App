from models.Student_Course import Student_Course
from models.Student_Course_Assignment import Student_Course_Assignment
from models.Trainer_Course import Trainer_Course
from models.collections import *
from operations.assignment_management import isAssignmentEntryExist
from operations.course_management import isCourseEntryExist
from operations.student_management import isStudentEntryExist
from operations.trainer_management import isTrainerEntryExist


def isStudentCourseEntryExist(studentID, courseID):
    isExist = False
    for o in Students_Courses:
        if o.get_studentID == studentID and o.get_courseID == courseID:
            isExist = True
            break
    return isExist


def printAllStudents_Courses():
    print("Current Students - Courses\n")
    for student_course in Students_Courses:
        print(student_course.__str__())


def insertStudentCourseRelation():
    insertEntry = True

    while insertEntry:
        studentID = int(input('Enter student id: '))
        courseID = int(input('Enter course id: '))
        if not isStudentCourseEntryExist(studentID, courseID):
            if isStudentEntryExist(studentID) and isCourseEntryExist(courseID):
                Student_Course(studentID, courseID)
            else:
                print('Student ID or Course ID is invalid')
        else:
            print('Entry already Exists')\

        insertEntry = input(
            "Add new Student Course Relationship?\nPress N to stop else hit Enter "
        ) != "N"

    printAllStudents_Courses()


#Trainer - Course


def isTrainerCourseEntryExist(trainerID, courseID):
    isExist = False
    for i, o in enumerate(Trainers_Courses):
        if o.get_trainerID == trainerID and o.get_courseID == courseID:
            isExist = True
            break
    return isExist


def printAllTrainers_Courses():
    print("Current Trainers - Courses\n")
    for trainer_course in Trainers_Courses:
        print(trainer_course.__str__())


def inserttrainerCourseRelation():
    insertEntry = True

    while insertEntry:
        trainerID = int(input('Enter trainer id: '))
        courseID = int(input('Enter course id: '))
        if not isTrainerCourseEntryExist(trainerID, courseID):
            if isTrainerEntryExist(trainerID) and isCourseEntryExist(courseID):
                Trainer_Course(trainerID, courseID)
            else:
                print('trainer ID or Course ID is invalid')
        else:
            print('Entry already Exists')\

        insertEntry = input(
            "Add new trainer Course Relationship?\nPress N to stop else hit Enter "
        ) != "N"

    printAllTrainers_Courses()


#Student - Assignment
def isStudentAssignmentEntryExist(studentCourseID, assignmentID):
    isExist = False
    for student_course_assignment in Students_Courses_Assignments:
        if student_course_assignment.get_student_course_ID == studentCourseID and student_course_assignment.get_assignmentID == assignmentID:
            isExist = True
            break
    return isExist


def printAllStudents_Assignments():
    print("Current Students - Assignments\n")
    for student_assignment in Students_Courses_Assignments:
        print(student_assignment.__str__())


def insertStudentAssignmentRelation():
    insertEntry = True

    while insertEntry:
        studentCourseID = int(input('Enter student course relation id: '))
        assignmentID = int(input('Enter assignment id: '))
        if not isStudentAssignmentEntryExist(studentCourseID, assignmentID):
            if isAssignmentEntryExist(assignmentID):
                Student_Course_Assignment(studentCourseID, assignmentID)
            else:
                print('Student ID is invalid')
        else:
            print('Entry already Exists')\

        insertEntry = input(
            "Add new Student Assignment Relationship?\nPress N to stop else hit Enter "
        ) != "N"

    printAllStudents_Assignments()


def getStudentsCoursesKey(student_course):
    return student_course.get_studentID

#returns student ids of students attending multiple courses

def studentsMultipleCourses():
    studentsCourses = Students_Courses.copy()
    studentsCourses.sort(key=getStudentsCoursesKey)

    currentStdId=None
    count=0
    for studentCourse in studentsCourses:
        if currentStdId == None:
            currentStdId = studentCourse.get_studentID
        if currentStdId != studentCourse.get_studentID:
            if count > 1:
                Students_Multiple_Courses.append(currentStdId)
            currentStdId = studentCourse.get_studentID
            count = 0
        count=count+1
    
    print(Students_Multiple_Courses)
