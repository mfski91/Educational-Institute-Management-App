from models.Student import Student
from models.collections import Students
from operations.helper import DateInputToDate


def isStudentEntryExist(studentID):
    isExist = False
    for i in range(0, len(Students), 1):
        if Students[i].get_id == studentID:
            isExist = True
            break
    return isExist


def printAllStudents():
    print("Current Students\n")
    for student in Students:
        print(student.__str__())


def insertNewStudent():
    insertNewStudent = True

    while insertNewStudent:
        date = DateInputToDate('birth')
        Student(str(input("Enter First Name: ")),
                str(input("Enter Last Name: ")), date,
                int(input("Enter tuition fees: ")))
        insertNewStudent = input(
            "Add new Student?\nPress N to stop else hit Enter ") != "N"

    printAllStudents()

