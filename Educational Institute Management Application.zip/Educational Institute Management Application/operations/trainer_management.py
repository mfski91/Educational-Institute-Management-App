from models.Trainer import Trainer
from models.collections import Trainers


def isTrainerEntryExist(trainerID):
    isExist = False
    for i in range(0, len(Trainers), 1):
        if Trainers[i].get_id == trainerID:
            isExist = True
            break
    return isExist


def printAllTrainers():
    print("Current Trainers\n")
    for trainer in Trainers:
        print(trainer.__str__())


def insertNewTrainer():
    insertNewTrainer = True

    while insertNewTrainer:
        Trainer(str(input("Enter First Name: ")),
                str(input("Enter Last Name: ")), str(input("Enter Subject: ")))
        insertNewTrainer = input(
            "Add new Trainer?\nPress N to stop else hit Enter ") != "N"

    printAllTrainers()

